# Projeto CRUD com Angular 9 - Curso Grátis!!!

Mais informações...
[Angular 9 - Essencial](https://www.cod3r.com.br/courses/angular-9-essencial)
